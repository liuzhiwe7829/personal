package com.neo.drools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDroolsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDroolsApplication.class, args);
	}



}
