找了一些drools资料都是零零碎碎，因此搭建了一个简单的springBoot+drools6.2  demo项目，比较适合初学者学习
  