package com.licc.drools.util;

/**
 *
 * @author lichangchao
 * @version 1.0.0
 * @date 2017/8/16 9:48
 * @see
 */
public class MessageUtil {
   public  static  void  outMsg(String message){
     System.out.println("MessageUtil: "+message);
   }
}
